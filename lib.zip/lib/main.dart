import 'package:dintalk/Navbar/Navbar.dart';
import 'package:dintalk/user/Homepage/home.dart';
import 'package:flutter/material.dart';

void main(){
  runApp(const MaterialApp(
    home: Navbar(),
    // home: HomeUser(),
    debugShowCheckedModeBanner: false,
  ));
}