import 'package:flutter/material.dart';

class EventUser extends StatefulWidget {
  const EventUser({super.key});

  @override
  State<EventUser> createState() => _EventUserState();
}

class _EventUserState extends State<EventUser> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Test'),
      ),
    );
  }
}
