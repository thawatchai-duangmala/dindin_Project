import 'package:flutter/material.dart';

class NotiUser extends StatefulWidget {
  const NotiUser({super.key});

  @override
  State<NotiUser> createState() => _NotiUserState();
}

class _NotiUserState extends State<NotiUser> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}